### MS Visual Studio

# To install the optional CI testing:
1. Download "googletest" from https://github.com/google/googletest
2. Copy the follow file and folders into the empty _CPP/Tests/googletest_ folder ...
   a. CMakeLists.txt 
   b. googlemock subfolder 
   c. googletest" subfolder
   
In Visual Studio, open Clipper2's CPP folder and wait for ...
  _CMake generation finished._
Rebuild all files.
