td_1 = "Index"
url_1 = "_Body.htm"

td_2 = "Overview"
url_2 = "Overview.htm"

td_3 = " Units "
td_3_1 = "Clipper"
url_3_1 = "Units/Clipper/_Body.htm"
td_3_2 = "Clipper.Core"
url_3_2 = "Units/Clipper.Core/_Body.htm"
td_3_3 = "Clipper.Engine"
url_3_3 = "Units/Clipper.Engine/_Body.htm"
td_3_4 = "Clipper.Offset"
url_3_4 = "Units/Clipper.Offset/_Body.htm"
td_3_5 = "Clipper.Minkowski"
url_3_5 = "Units/Clipper.Minkowski/_Body.htm"

td_4 = "Examples"
url_4 = "Examples.htm"

td_5 = "Rounding"
url_5 = "Rounding.htm"

td_6 = "FAQ"
url_6 = "FAQ.htm"

td_7 = "Trigonometry"
url_7 = "Trigonometry.htm"

